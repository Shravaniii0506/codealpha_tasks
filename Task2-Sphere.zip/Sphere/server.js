const express = require("express");
const mongoose = require("mongoose");
const session = require("express-session");
const path = require("path");

const app = express();
const PORT = 3000;

/* ---------- MIDDLEWARE ---------- */
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.use(
  session({
    secret: "sphere_secret",
    resave: false,
    saveUninitialized: false
  })
);

/* ---------- DATABASE ---------- */
mongoose
  .connect("mongodb://127.0.0.1:27017/sphereDB")
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.log(err));

/* ---------- MODELS ---------- */
const User = mongoose.model("User", {
  username: String,
  password: String,
  followers: [String],
  following: [String]
});

const Post = mongoose.model("Post", {
  username: String,
  content: String,
  likes: { type: [String], default: [] },
  comments: {
    type: [{ username: String, text: String }],
    default: []
  }
});

/* ---------- ROUTES ---------- */

// LOGIN / REGISTER
app.get("/", (req, res) => res.redirect("/login"));

app.get("/login", (req, res) =>
  res.sendFile(path.join(__dirname, "views/login.html"))
);

app.get("/register", (req, res) =>
  res.sendFile(path.join(__dirname, "views/register.html"))
);

// FEED
app.get("/feed", (req, res) => {
  if (!req.session.user) return res.redirect("/login");
  res.sendFile(path.join(__dirname, "views/feed.html"));
});

app.get("/profile/:user", (req, res) => {
  if (!req.session.user) return res.redirect("/login");
  res.sendFile(path.join(__dirname, "views/profile.html"));
});

/* ---------- AUTH ---------- */

// REGISTER
app.post("/register", async (req, res) => {
  const { username, password } = req.body;

  const exists = await User.findOne({ username });
  if (exists) return res.send("User already exists");

  await User.create({
    username,
    password,
    followers: [],
    following: []
  });

  res.redirect("/login");
});

// LOGIN
app.post("/login", async (req, res) => {
  const user = await User.findOne(req.body);
  if (!user) return res.send("Invalid credentials");

  req.session.user = user.username;
  res.redirect("/feed");
});

// LOGOUT
app.get("/logout", (req, res) => {
  req.session.destroy(() => res.redirect("/login"));
});

/* ---------- POSTS ---------- */
app.post("/post", async (req, res) => {
  if (!req.session.user) return res.sendStatus(401);

  await Post.create({
    username: req.session.user,
    content: req.body.content
  });

  res.redirect("/feed");
});

/* ---------- FEED DATA ---------- */
app.get("/posts", async (req, res) => {
  const posts = await Post.find().sort({ _id: -1 });
  res.json({
    user: req.session.user,
    posts
  });
});

/* ---------- PROFILE DATA ---------- */
app.get("/profile-data/:user", async (req, res) => {
  const profileUser = req.params.user;
  const loggedUser = req.session.user;

  const user = await User.findOne({ username: profileUser });
  const posts = await Post.find({ username: profileUser });

  res.json({
    username: profileUser,
    followers: user.followers.length,
    following: user.following.length,
    isFollowing: user.followers.includes(loggedUser),
    isMe: profileUser === loggedUser,
    posts
  });
});

/* ---------- FOLLOW / UNFOLLOW ---------- */
app.post("/follow/:user", async (req, res) => {
  if (!req.session.user) return res.sendStatus(401);

  const me = req.session.user;
  const other = req.params.user;

  if (me === other) return res.sendStatus(400);

  const meUser = await User.findOne({ username: me });
  const otherUser = await User.findOne({ username: other });

  if (meUser.following.includes(other)) {
    // UNFOLLOW
    meUser.following = meUser.following.filter(u => u !== other);
    otherUser.followers = otherUser.followers.filter(u => u !== me);
  } else {
    // FOLLOW
    meUser.following.push(other);
    otherUser.followers.push(me);
  }

  await meUser.save();
  await otherUser.save();

  res.sendStatus(200);
});

/* ---------- LIKE ---------- */
app.post("/like/:id", async (req, res) => {
  if (!req.session.user) return res.sendStatus(401);

  const post = await Post.findById(req.params.id);
  const user = req.session.user;

  if (post.likes.includes(user)) {
    post.likes = post.likes.filter(u => u !== user);
  } else {
    post.likes.push(user);
  }

  await post.save();
  res.sendStatus(200);
});

/* ---------- COMMENT ---------- */
app.post("/comment/:id", async (req, res) => {
  if (!req.session.user) return res.sendStatus(401);

  const post = await Post.findById(req.params.id);

  post.comments.push({
    username: req.session.user,
    text: req.body.text
  });

  await post.save();
  res.sendStatus(200);
});

/* ---------- SERVER ---------- */
app.listen(PORT, () =>
  console.log(`Server running at http://localhost:${PORT}`)
);

/* ---------- DELETE POST ---------- */
app.post("/delete-post/:id", async (req, res) => {
  const post = await Post.findById(req.params.id);
  if (post.username !== req.session.user) return res.sendStatus(403);
  await Post.findByIdAndDelete(req.params.id);
  res.sendStatus(200);
});