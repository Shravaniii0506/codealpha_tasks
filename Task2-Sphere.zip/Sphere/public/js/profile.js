const username = location.pathname.split("/").pop();

fetch(`/profile-data/${username}`)
  .then(res => res.json())
  .then(data => {
    document.getElementById("username").innerText = data.username;
    document.getElementById("followers").innerText = data.followers;
    document.getElementById("following").innerText = data.following;

    const btn = document.getElementById("followBtn");

    if (data.isMe) {
      btn.style.display = "none";
    } else {
      btn.innerText = data.isFollowing ? "Unfollow" : "Follow";
      btn.onclick = () => {
        fetch(`/follow/${data.username}`, { method: "POST" })
          .then(() => location.reload());
      };
    }

    const postsDiv = document.getElementById("posts");

    data.posts.forEach(p => {
      postsDiv.innerHTML += `
        <div style="border:1px solid #ddd;padding:10px;margin-bottom:10px">
          <p>${p.content}</p>
        </div>
      `;
    });
  });