fetch("/posts")
  .then(res => res.json())
  .then(data => {
    document.getElementById("myProfile").href = `/profile/${data.user}`;

    const feed = document.getElementById("feed");

    data.posts.forEach(p => {
      feed.innerHTML += `
        <div style="border:1px solid #ddd;padding:10px;margin-bottom:10px">

          <a href="/profile/${p.username}" style="font-weight:bold">
            ${p.username}
          </a>

          <p>${p.content}</p>

          <span style="cursor:pointer" onclick="likePost('${p._id}')">
            ❤️ ${p.likes.length}
          </span>

          ${
            p.username === data.user
              ? `<span style="cursor:pointer;color:red;margin-left:10px"
                   onclick="deletePost('${p._id}')">🗑</span>`
              : ""
          }

          <div style="margin-top:10px">
            ${p.comments.map((c,i)=>`
              <div>
                <b>${c.username}</b>: ${c.text}
                ${
                  c.username === data.user
                    ? `<span style="color:red;cursor:pointer"
                         onclick="deleteComment('${p._id}',${i})"> x</span>`
                    : ""
                }
              </div>
            `).join("")}
          </div>

          <input placeholder="Add comment..."
            onkeydown="if(event.key==='Enter') addComment('${p._id}',this)">
        </div>
      `;
    });
  });

function likePost(id){
  fetch(`/like/${id}`,{method:"POST"}).then(()=>location.reload());
}

function deletePost(id){
  fetch(`/delete-post/${id}`,{method:"POST"}).then(()=>location.reload());
}

function addComment(id,input){
  fetch(`/comment/${id}`,{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({text:input.value})
  }).then(()=>location.reload());
}

function deleteComment(pid,i){
  fetch(`/delete-comment/${pid}/${i}`,{method:"POST"})
    .then(()=>location.reload());
}