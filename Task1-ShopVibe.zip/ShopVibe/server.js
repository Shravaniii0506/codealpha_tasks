const fs = require("fs");

const USERS_DB = "./data/users.json";
const PRODUCTS_DB = "./data/products.json";
const ORDERS_DB = "./data/orders.json";

const express = require("express");
const session = require("express-session");
const path = require("path");

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

app.use(
  session({
    secret: "shopvibe-secret",
    resave: false,
    saveUninitialized: true,
  })
);

// Sample products (fixed price like real world)
const products = {
  smartphone: { name: "Smartphone", price: 14999 },
  laptop: { name: "Laptop", price: 55999 },
  headphones: { name: "Headphones", price: 2999 },
};

// Auth middleware
function auth(req, res, next) {
  if (req.session.user) next();
  else res.redirect("/login");
}

// ---------- AUTH ----------
app.get("/", (req, res) => res.redirect("/login"));

app.get("/login", (req, res) =>
  res.sendFile(path.join(__dirname, "views/login.html"))
);

app.get("/register", (req, res) =>
  res.sendFile(path.join(__dirname, "views/register.html"))
);

app.post("/register", (req, res) => {
  const users = JSON.parse(fs.readFileSync(USERS_DB));
  users.push({
    email: req.body.email,
    password: req.body.password
  });
  fs.writeFileSync(USERS_DB, JSON.stringify(users, null, 2));
  res.redirect("/login");
});


app.post("/login", (req, res) => {
  const users = JSON.parse(fs.readFileSync(USERS_DB));

  const user = users.find(
    u => u.email === req.body.email &&
         u.password === req.body.password
  );

  if (!user) {
    return res.send("Invalid email or password");
  }

  req.session.user = user.email;
  req.session.cart = [];
  res.redirect("/products");
});



app.get("/logout", (req, res) => {
  req.session.destroy(() => res.redirect("/login"));
});

// ---------- PRODUCTS ----------
app.get("/products", auth, (req, res) =>
  res.sendFile(path.join(__dirname, "views/products.html"))
);

app.get("/product/:id", auth, (req, res) => {
  const product = products[req.params.id];
  res.send(`
    <html>
    <head><link rel="stylesheet" href="/css/style.css"></head>
    <body>
      <header>
        <img src="/images/logo.png" class="logo-small">
        <nav>
          <a href="/products">Back</a>
          <a href="/cart">Cart</a>
        </nav>
      </header>

      <div class="product-detail">
        <img src="/images/logo.png" class="product-img">
        <div>
          <h2>${product.name}</h2>
          <p class="price">₹${product.price}</p>

          <form method="POST" action="/add-to-cart">
            <input type="hidden" name="name" value="${product.name}">
            <input type="hidden" name="price" value="${product.price}">
            <label>Quantity</label>
            <input type="number" name="qty" value="1" min="1">
            <button>Add to Cart</button>
          </form>
        </div>
      </div>
    </body>
    </html>
  `);
});

// ---------- CART ----------
app.post("/add-to-cart", auth, (req, res) => {
  const item = {
    name: req.body.name,
    price: Number(req.body.price),
    qty: Number(req.body.qty),
    total: Number(req.body.price) * Number(req.body.qty),
  };
  req.session.cart.push(item);
  res.redirect("/cart");
});

app.get("/cart", auth, (req, res) => {
  let total = 0;
  let items = req.session.cart
    .map((i) => {
      total += i.total;
      return `<p>${i.name} × ${i.qty} = ₹${i.total}</p>`;
    })
    .join("");

  res.send(`
    <html>
    <head><link rel="stylesheet" href="/css/style.css"></head>
    <body>
      <header>
        <img src="/images/logo.png" class="logo-small">
        <nav>
          <a href="/products">Shop</a>
          <a href="/logout">Logout</a>
        </nav>
      </header>

      <div class="card wide">
        <h2>Your Cart</h2>
        ${items}
        <hr>
        <h3>Total: ₹${total}</h3>
        <button onclick="alert('Order Placed Successfully!')">
          Place Order
        </button>
      </div>
    </body>
    </html>
  `);
});

app.post("/order", auth, (req, res) => {
  const orders = JSON.parse(fs.readFileSync(ORDERS_DB));

  const total = req.session.cart.reduce((s, i) => s + i.total, 0);

  orders.push({
    user: req.session.user,
    items: req.session.cart,
    total,
    date: new Date().toISOString()
  });

  fs.writeFileSync(ORDERS_DB, JSON.stringify(orders, null, 2));

  req.session.cart = [];
  res.send("✅ Order placed successfully!");
});


app.listen(3000, () =>
  console.log("ShopVibe running at http://localhost:3000")
);
